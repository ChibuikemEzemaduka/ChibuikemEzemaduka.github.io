(function () {
  "use strict";
  function setup() {
    document.querySelectorAll("[data-work-archive]").forEach(function (archive) {
      if (archive.dataset.ready) return;
      archive.dataset.ready = "true";
      var search = archive.querySelector("[data-work-search]");
      var entries = Array.from(archive.querySelectorAll("[data-work-entry]"));
      var buttons = Array.from(archive.querySelectorAll("[data-topic]"));
      var count = archive.querySelector("[data-result-count]");
      var empty = archive.querySelector("[data-empty-state]");
      var topic = "All work";
      function filter() {
        var query = search.value.trim().toLowerCase();
        var visible = 0;
        entries.forEach(function (entry) {
          var matches = (topic === "All work" || entry.dataset.topics.split(",").includes(topic)) && entry.dataset.search.includes(query);
          entry.hidden = !matches;
          if (matches) visible++;
        });
        count.textContent = visible + (visible === 1 ? " entry" : " entries") + (topic === "All work" ? "" : " · " + topic);
        empty.hidden = visible !== 0;
        buttons.forEach(function (button) { button.setAttribute("aria-pressed", String(button.dataset.topic === topic)); });
      }
      archive.addEventListener("click", function (event) {
        var button = event.target.closest("[data-topic]");
        if (button && archive.contains(button)) { topic = button.dataset.topic; filter(); }
        var reset = event.target.closest("[data-clear-search]");
        if (reset && archive.contains(reset)) { topic = "All work"; search.value = ""; filter(); search.focus(); }
      });
      search.addEventListener("input", filter);
      window.addEventListener("pageshow", filter);
      filter();
    });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", setup);
  else setup();
})();
